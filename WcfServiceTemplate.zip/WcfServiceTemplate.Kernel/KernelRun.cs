using System.ServiceModel;
using $ext_projectname$.IContract;
using $ext_projectname$.IContract.Contract;

namespace $safeprojectname$
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class KernelRun : IModel
    {
        public Index Index()
        {
            return new Index {Param = "Default"};
        }
    }
}
