﻿using System.Runtime.Serialization;

namespace $safeprojectname$.Contract
{
    [DataContract]
    public class Index
    {
        [DataMember]
        public string Param { get; set; }
    }
}
