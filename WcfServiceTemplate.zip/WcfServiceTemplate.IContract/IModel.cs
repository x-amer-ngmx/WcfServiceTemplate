﻿using System.ServiceModel;
using $safeprojectname$.Contract;

namespace $safeprojectname$
{
    [ServiceContract(Namespace = "", Name = "")]
    public interface IModel
    {
        [OperationContract(Name = "", Action = "", ReplyAction = "")]
        Index Index();
    }
}
